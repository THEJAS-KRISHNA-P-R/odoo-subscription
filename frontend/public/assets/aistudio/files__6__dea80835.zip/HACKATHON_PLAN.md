# HACKATHON_PLAN.md — Odoo x Make-A-Ton 9.0 Virtual Round (31 Oct 2026)

Team: Thejas (leader) + Rohan. Human-facing plan: schedule, roles, video, problem statement.
Technical rules for code and agents are in `AGENTS.md`.

**Hard clock (IST):** problem statements 09:00 · evaluator `hapt-odoo` added to repo by 10:00 · coding ends 17:00 · video link submitted by 17:30.
Rules from the portal: leader alone selects the problem (final), leader alone submits repo and video, code in a single branch, both members must have confirmed their participation.

## 1. Plan for the day (IST) — adapt once the problem statement is known

| Time | Goal | Owner |
|---|---|---|
| 09:00–09:20 | Read ALL problem statements. Pick the one with the clearest data model and an achievable core in 6h. **Leader selects; it is final.** | both, Thejas clicks |
| 09:20–09:35 | Fill section 3 below (problem, users, 3–5 core flows, explicit non-goals). | both |
| 09:35–10:00 | Create repo, add `hapt-odoo` as collaborator, push scaffold + docker compose. Draft schema + ERD. | Thejas / Rohan scaffolds Next.js |
| 10:00–10:45 | Schema migration + seed done. API contract (endpoints + error shape) written in README. | Thejas / Rohan builds layout + design tokens |
| 10:45–13:30 | Vertical slices, core flow first, DB → API → UI end to end, one flow at a time. | split |
| 13:30–14:00 | Break. | |
| 14:00–15:30 | Remaining flows, validation everywhere, loading/empty/error states. Cross-review each other's code. | split, then swap |
| 15:30–16:15 | Polish, seed data realism, README + schema diagram, run the quality gates in `AGENTS.md` section 5. | both |
| **16:30** | **CODE FREEZE** (bugfix only). Final push. Confirm `hapt-odoo` can see the repo. | both |
| 16:30–17:15 | Record video (screen + voice, both of us speak). | both |
| 17:15 | Submit repo link (Thejas, "Submit GitHub Repo Link") + video link ("Submit Video Solution"). Re-open both links logged out to confirm they work. Deadline 17:30. | Thejas |

Scope discipline: ship a **complete, polished core** over a wide half-working app. Cut features before cutting validation, DB quality, or UI states.

## 2. Video script (5 min max, both speak)

1. Thejas (30s): problem + who it is for.
2. Rohan (60s): live UI demo of the core flow, show an invalid input being handled.
3. Thejas (90s): schema/ERD, why these constraints and indexes, why local Postgres and no BaaS.
4. Rohan (60s): frontend structure, validation, state handling.
5. Both (45s): what we'd build next, how Git was used (show commit history from both).

Show real data coming from the DB. Do not read code line by line; explain decisions.

## 3. Problem statement

- Chosen: **Subscription Management System** (Brightloop Software).
- Full spec, data model, rules, UI plan, build order and cut list: `BUILD_PLAN.md`.
- UI reference: `design.md` plus the Wise screenshots.
