# BUILD_PLAN.md — Brightloop Subscription Management System

Problem: *Subscription Management System* (Brightloop Software). Team: Thejas + Rohan. 8h window, code freeze 16:30 IST.
Rules for code and agents: `AGENTS.md`. Schedule and video: `HACKATHON_PLAN.md`. This file fills section 3 of that plan and is the spec agents build from.
UI source of truth: `design.md` (Wise-style tokens) + the three Wise screenshots.

---

## 1. Frame (what we are really building)

**One sentence:** a billing engine that never bills twice or skips, wrapped in a calm Wise-style UI with three role views.

**Jobs to be done**

| Who | When | They want to | So that |
|---|---|---|---|
| Customer | I need to see what I pay | see my subscriptions and invoices, pause/close/renew where allowed | I never email anyone |
| Staff | It is billing day | generate every due invoice with one click, confirm/send/print, record payments | nothing is typed by hand |
| Admin | I launch a plan | configure products, variants, plans, taxes, discounts, staff | rules run on their own |
| Finance lead | month end | see active subs, revenue, outstanding, overdue in one page | answer in seconds not days |

**Riskiest assumptions (test these first, they decide the score)**

1. Billing idempotency: running billing twice, or two staff clicking at once, must produce zero duplicates. Enforced by the DB (`UNIQUE(subscription_id, period_start)`), proven by a test.
2. Money correctness: integer minor units end to end, tax and discount order fixed and tested.
3. "Every page under 2s with thousands of subscriptions": seed 5,000 subs and 20,000 invoices and measure. Indexes designed up front, not bolted on.
4. RBAC is server-enforced, not hidden buttons.

**Decisions on ambiguous spec points (state these in the video, they show judgment)**

| # | Question | Decision |
|---|---|---|
| D1 | "more than eight" characters | min **9** chars + upper + lower + special. Same rule client and server, live checklist in UI |
| D2 | Plan price vs product price | Line price = `product.sales_price + variant.extra_price`. Plan `price` is the recurring plan fee, added as one auto line "Plan fee". `shortcut: one fee line per plan, split if plans need tiers` |
| D3 | Overdue | Derived, not a status: `status='confirmed' AND due_date < today AND paid < total`. Invoice states stay Draft, Confirmed, Paid (+ Cancelled) |
| D4 | Partial payments | Allowed. Invoice becomes Paid when `paid >= total`. Overpay rejected (422) |
| D5 | Pause | Subscription status `paused` (only if plan.pausable). Billing skips paused. Resume sets next billing to the next future boundary, no back-billing |
| D6 | Discount order | line discount first, then tax on the discounted amount. Percent in basis points, fixed in minor units. Never below zero |
| D7 | Discount usage | `used_count` +1 when the invoice is generated, released on cancel. Stops at `usage_limit` or `end_date` |
| D8 | Missed billing days | Engine catches up period by period (cap 12 per run) so nothing is skipped |
| D9 | Customer sign-up | Public sign-up always creates role `customer`. Staff created only by admin |
| D10 | Payments by customers | Out of scope. Team records payments (matches the statement) |

**Non-goals:** payment gateway, multi-currency (INR only), proration, dunning emails, tax filing, mobile app.

---

## 2. Requirements coverage map (judging checklist)

Every line from the statement maps to a feature. Tick them off at 15:30.

| Statement | Feature | Where |
|---|---|---|
| Email unique, password rules, reset link by email | Sign-up, forgot/reset | auth |
| Admin / staff / customer roles, only admin adds staff | RBAC middleware, Team page | auth, users |
| Product: name, type, sales, cost, notes, variants (+560 for Odoo brand) | Products + variants | catalog |
| Plan: price, billing daily/weekly/monthly/yearly, min qty, dates, auto-close / early close / pause / renew per plan | Plans | plans |
| Quotation template with plan + lines + validity days | Templates | templates |
| Subscription number, customer, plan, dates, payment terms, lines; Draft → Quotation → Confirmed → Active → Closed | Subscriptions + status history | subscriptions |
| Billing day: invoices auto from subscriptions, no double/skip | Billing engine | billing |
| Auto taxes from admin rules | Tax rules | taxes |
| Confirm / cancel / send / print invoice; Draft → Confirmed → Paid | Invoice actions | invoices |
| Admin-only discount rules (fixed/percent, min purchase/qty, dates, usage limit, product or subscription scope), auto-applied next invoice | Discounts + auto-apply | discounts |
| Payments with method, amount, date, note per invoice; paid vs outstanding | Payments | payments |
| Finance dashboard: active subs, revenue, owed, overdue, filters, summary; < 2s | Reports | reports |
| Customer portal: own subscriptions and invoices, self-manage | Portal | portal |

---

## 3. Architecture (ADR-002, Accepted)

**Context:** 8h, two people, judged on DB design, modularity, security, performance.
**Decision:** modular monolith. Go (stdlib `net/http`, Go 1.22 routing) + `pgx` + PostgreSQL 16 (docker compose) + Next.js (App Router, TypeScript, Tailwind). Plain SQL migrations.
**Options:** (A) modular monolith, chosen. (B) microservices: more moving parts than 8h allows, no gain. (C) Next.js full-stack with an ORM: weaker story on DB design and billing concurrency.
**Trade-offs:** less framework magic, more explicit SQL. That is the point, judges read the SQL.
**Consequences:** easy: one binary, transactions across billing/discounts/invoices. Hard: we hand-roll validation helpers (small). Revisit: background jobs if scale demands a queue.

**Key mechanisms**

- Money: `BIGINT` minor units (paise), rates in basis points. No floats anywhere.
- Auth: bcrypt (cost 12), JWT in httpOnly + SameSite=Lax cookie, 8h. Role in claims, re-checked against DB role on sensitive routes. Login rate limit (in-memory, `shortcut: single instance, move to Redis if scaled`).
- Reset: 32 random bytes, only SHA-256 stored, 30 min expiry, single use, same response whether or not the email exists. Mail via stdlib `net/smtp`; docker compose runs **Mailpit** so the link is visible during the demo.
- Billing engine: one function `RunBilling(asOf date)`. Per subscription its own transaction: `SELECT ... FOR UPDATE SKIP LOCKED`, insert invoice with `ON CONFLICT (subscription_id, period_start) DO NOTHING`, advance `next_billing_date`. Triggered by a daily ticker goroutine **and** a manual admin/staff button. Both are safe to run together.
- Number generators: Postgres sequences (`SUB-000123`, `INV-2026-000456`), no gaps logic needed.
- Errors: single shape `{"error":"validation_failed","fields":{"email":"Enter a valid email"}}`.
- Pagination: `limit` (max 100) + `cursor` or `page`; every list endpoint filters and sorts server-side.

---

## 4. Data model (PostgreSQL)

`migrations/001_init.sql` — this is the schema to build. Constraints do the validating, the API only maps errors.

```sql
CREATE EXTENSION IF NOT EXISTS citext;

CREATE TYPE role_t        AS ENUM ('admin','staff','customer');
CREATE TYPE period_t      AS ENUM ('daily','weekly','monthly','yearly');
CREATE TYPE sub_status_t  AS ENUM ('draft','quotation','confirmed','active','paused','closed');
CREATE TYPE inv_status_t  AS ENUM ('draft','confirmed','paid','cancelled');
CREATE TYPE disc_kind_t   AS ENUM ('fixed','percent');
CREATE TYPE disc_scope_t  AS ENUM ('product','subscription');
CREATE TYPE pay_method_t  AS ENUM ('cash','bank_transfer','card','upi','cheque');

CREATE TABLE users (
  id BIGSERIAL PRIMARY KEY,
  email CITEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  full_name TEXT NOT NULL CHECK (length(trim(full_name)) > 0),
  role role_t NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE password_resets (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL UNIQUE,
  expires_at TIMESTAMPTZ NOT NULL,
  used_at TIMESTAMPTZ
);
CREATE TABLE customers (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT UNIQUE REFERENCES users(id) ON DELETE SET NULL,
  name TEXT NOT NULL, company TEXT, phone TEXT, billing_address TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE taxes (
  id BIGSERIAL PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  rate_bp INT NOT NULL CHECK (rate_bp BETWEEN 0 AND 10000),
  is_active BOOLEAN NOT NULL DEFAULT true
);
CREATE TABLE payment_terms (
  id BIGSERIAL PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  due_days INT NOT NULL CHECK (due_days >= 0)
);
CREATE TABLE products (
  id BIGSERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('software','service','addon','physical')),
  sales_price_minor BIGINT NOT NULL CHECK (sales_price_minor >= 0),
  cost_price_minor  BIGINT NOT NULL CHECK (cost_price_minor  >= 0),
  tax_id BIGINT REFERENCES taxes(id),
  notes TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true
);
CREATE TABLE product_variants (
  id BIGSERIAL PRIMARY KEY,
  product_id BIGINT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  attribute TEXT NOT NULL,            -- e.g. Brand
  value TEXT NOT NULL,                -- e.g. Odoo
  extra_price_minor BIGINT NOT NULL DEFAULT 0,   -- e.g. 56000 = 560.00
  UNIQUE (product_id, attribute, value)
);

CREATE TABLE plans (
  id BIGSERIAL PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  price_minor BIGINT NOT NULL CHECK (price_minor >= 0),
  billing_period period_t NOT NULL,
  min_quantity INT NOT NULL DEFAULT 1 CHECK (min_quantity >= 1),
  available_from DATE NOT NULL,
  available_to DATE,
  auto_close BOOLEAN NOT NULL DEFAULT false,   -- closes itself at expiry
  closable BOOLEAN NOT NULL DEFAULT true,      -- can be closed early
  pausable BOOLEAN NOT NULL DEFAULT false,
  renewable BOOLEAN NOT NULL DEFAULT true,
  is_active BOOLEAN NOT NULL DEFAULT true,
  CHECK (available_to IS NULL OR available_to >= available_from)
);
CREATE TABLE quotation_templates (
  id BIGSERIAL PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  plan_id BIGINT NOT NULL REFERENCES plans(id),
  validity_days INT NOT NULL CHECK (validity_days > 0)
);
CREATE TABLE quotation_template_lines (
  id BIGSERIAL PRIMARY KEY,
  template_id BIGINT NOT NULL REFERENCES quotation_templates(id) ON DELETE CASCADE,
  product_id BIGINT NOT NULL REFERENCES products(id),
  variant_id BIGINT REFERENCES product_variants(id),
  quantity INT NOT NULL CHECK (quantity > 0)
);

CREATE SEQUENCE sub_seq; CREATE SEQUENCE inv_seq;
CREATE TABLE subscriptions (
  id BIGSERIAL PRIMARY KEY,
  number TEXT NOT NULL UNIQUE,
  customer_id BIGINT NOT NULL REFERENCES customers(id),
  plan_id BIGINT NOT NULL REFERENCES plans(id),
  template_id BIGINT REFERENCES quotation_templates(id),
  payment_term_id BIGINT NOT NULL REFERENCES payment_terms(id),
  status sub_status_t NOT NULL DEFAULT 'draft',
  start_date DATE NOT NULL,
  expiry_date DATE NOT NULL,
  quote_valid_until DATE,
  next_billing_date DATE,                 -- NULL unless active
  paused_at TIMESTAMPTZ,
  created_by BIGINT NOT NULL REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (expiry_date >= start_date)
);
CREATE TABLE subscription_lines (
  id BIGSERIAL PRIMARY KEY,
  subscription_id BIGINT NOT NULL REFERENCES subscriptions(id) ON DELETE CASCADE,
  product_id BIGINT REFERENCES products(id),     -- NULL = plan fee line
  variant_id BIGINT REFERENCES product_variants(id),
  description TEXT NOT NULL,
  quantity INT NOT NULL CHECK (quantity > 0),
  unit_price_minor BIGINT NOT NULL CHECK (unit_price_minor >= 0),
  tax_id BIGINT REFERENCES taxes(id)
);
CREATE TABLE subscription_events (
  id BIGSERIAL PRIMARY KEY,
  subscription_id BIGINT NOT NULL REFERENCES subscriptions(id) ON DELETE CASCADE,
  from_status sub_status_t, to_status sub_status_t NOT NULL,
  actor_id BIGINT REFERENCES users(id), note TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE discounts (
  id BIGSERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  kind disc_kind_t NOT NULL,
  value BIGINT NOT NULL CHECK (value > 0),       -- minor units if fixed, basis points if percent
  min_purchase_minor BIGINT NOT NULL DEFAULT 0,
  min_quantity INT NOT NULL DEFAULT 0,
  start_date DATE NOT NULL, end_date DATE NOT NULL,
  usage_limit INT CHECK (usage_limit IS NULL OR usage_limit > 0),
  used_count INT NOT NULL DEFAULT 0 CHECK (used_count >= 0),
  scope disc_scope_t NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT true,
  CHECK (end_date >= start_date),
  CHECK (kind <> 'percent' OR value <= 10000),
  CHECK (usage_limit IS NULL OR used_count <= usage_limit)
);
CREATE TABLE discount_products (
  discount_id BIGINT REFERENCES discounts(id) ON DELETE CASCADE,
  product_id  BIGINT REFERENCES products(id)  ON DELETE CASCADE,
  PRIMARY KEY (discount_id, product_id)
);
CREATE TABLE discount_subscriptions (
  discount_id BIGINT REFERENCES discounts(id) ON DELETE CASCADE,
  subscription_id BIGINT REFERENCES subscriptions(id) ON DELETE CASCADE,
  PRIMARY KEY (discount_id, subscription_id)
);

CREATE TABLE invoices (
  id BIGSERIAL PRIMARY KEY,
  number TEXT NOT NULL UNIQUE,
  subscription_id BIGINT NOT NULL REFERENCES subscriptions(id),
  customer_id BIGINT NOT NULL REFERENCES customers(id),
  status inv_status_t NOT NULL DEFAULT 'draft',
  period_start DATE NOT NULL, period_end DATE NOT NULL,
  issue_date DATE NOT NULL, due_date DATE NOT NULL,
  subtotal_minor BIGINT NOT NULL, discount_minor BIGINT NOT NULL DEFAULT 0,
  tax_minor BIGINT NOT NULL, total_minor BIGINT NOT NULL,
  paid_minor BIGINT NOT NULL DEFAULT 0,
  sent_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (subscription_id, period_start),              -- the "never bill twice" guarantee
  CHECK (paid_minor >= 0 AND paid_minor <= total_minor),
  CHECK (total_minor >= 0)
);
CREATE TABLE invoice_lines (
  id BIGSERIAL PRIMARY KEY,
  invoice_id BIGINT NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
  product_id BIGINT REFERENCES products(id),
  description TEXT NOT NULL,
  quantity INT NOT NULL, unit_price_minor BIGINT NOT NULL,
  discount_minor BIGINT NOT NULL DEFAULT 0,
  tax_rate_bp INT NOT NULL DEFAULT 0, tax_minor BIGINT NOT NULL DEFAULT 0,
  amount_minor BIGINT NOT NULL                          -- after discount, before tax
);
CREATE TABLE invoice_discounts (                        -- audit of what was applied
  invoice_id BIGINT REFERENCES invoices(id) ON DELETE CASCADE,
  discount_id BIGINT REFERENCES discounts(id),
  amount_minor BIGINT NOT NULL,
  PRIMARY KEY (invoice_id, discount_id)
);
CREATE TABLE payments (
  id BIGSERIAL PRIMARY KEY,
  invoice_id BIGINT NOT NULL REFERENCES invoices(id),
  method pay_method_t NOT NULL,
  amount_minor BIGINT NOT NULL CHECK (amount_minor > 0),
  paid_on DATE NOT NULL, note TEXT,
  recorded_by BIGINT NOT NULL REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Performance (design for the 2s rule)
CREATE INDEX idx_sub_due      ON subscriptions (next_billing_date) WHERE status = 'active';
CREATE INDEX idx_sub_customer ON subscriptions (customer_id);
CREATE INDEX idx_sub_status   ON subscriptions (status);
CREATE INDEX idx_sub_lines    ON subscription_lines (subscription_id);
CREATE INDEX idx_inv_customer ON invoices (customer_id, issue_date DESC);
CREATE INDEX idx_inv_status   ON invoices (status, due_date);
CREATE INDEX idx_inv_open     ON invoices (due_date) WHERE status = 'confirmed' AND paid_minor < total_minor;
CREATE INDEX idx_inv_lines    ON invoice_lines (invoice_id);
CREATE INDEX idx_pay_invoice  ON payments (invoice_id);
CREATE INDEX idx_pay_date     ON payments (paid_on);
CREATE INDEX idx_evt_sub      ON subscription_events (subscription_id, created_at);
```

Totals are stored on the invoice (written in the same transaction as lines/payments), so the dashboard is plain indexed `SUM/COUNT`, no recomputation.

---

## 5. Business rules (the logic judges will read)

**Subscription state machine** (server rejects any other transition, each one writes `subscription_events`)

```
draft → quotation → confirmed → active ⇄ paused → closed
                         active → closed (if plan.closable, or auto at expiry if plan.auto_close)
closed → (renew, if plan.renewable) creates a new term: expiry extended, status active
```
- `confirmed → active` sets `next_billing_date = start_date`.
- Plan `min_quantity` enforced on every line. Plan availability window enforced at creation.
- Quotation validity: `quote_valid_until = today + template.validity_days`; expired quotes cannot be confirmed.
- Template → subscription copies lines (price snapshot at creation), staff may edit while in draft/quotation.

**Line price:** `unit_price = product.sales_price + variant.extra_price` (Odoo brand = +560.00).

**Invoice math (per line, in this order)**
1. `gross = qty × unit_price`
2. best applicable discount(s) → `line_discount` (clamped to `gross`)
3. `net = gross − line_discount`
4. `tax = round_half_up(net × rate_bp / 10000)`
5. invoice totals = sums. Subscription-scope discounts are spread pro-rata over lines (largest remainder so the sum is exact).

**Billing engine `RunBilling(asOf)`**
```
for each active, unpaused sub with next_billing_date <= asOf   (idx_sub_due)
  tx: lock row (FOR UPDATE SKIP LOCKED)
      loop (max 12): period = [next_billing_date, next + 1 period)
        build lines from subscription_lines + plan fee
        select eligible discounts (active, date window, used_count < limit,
          min qty / min purchase met, product or subscription scope)
        compute totals, INSERT invoice ... ON CONFLICT (subscription_id, period_start) DO NOTHING
        if inserted: write lines, invoice_discounts, used_count += 1
        next_billing_date += 1 period
      if plan.auto_close and next_billing_date > expiry_date → status closed
commit
```
Returns `{created, skipped, closed}` for the UI toast. Test: run twice, row counts unchanged.

**Invoice state machine:** `draft → confirmed → paid`; `draft|confirmed → cancelled` (only if `paid_minor = 0`, releases discount usage). "Send" emails PDF-style HTML via SMTP and stamps `sent_at`. "Print" = print stylesheet.

**Payments:** insert payment + `UPDATE invoices SET paid_minor = paid_minor + $amt` in one tx, lock the invoice row; reject if invoice not `confirmed` or amount > outstanding; flip to `paid` when equal.

**RBAC matrix**

| Capability | Admin | Staff | Customer |
|---|---|---|---|
| Add staff, manage users | ✅ | ❌ | ❌ |
| Products, variants, plans, taxes, payment terms, templates | ✅ | read | ❌ |
| Discount rules | ✅ create/edit | read | ❌ |
| Customers | ✅ | ✅ | own profile |
| Subscriptions create/confirm/transition | ✅ | ✅ | own: pause/close/renew only if plan allows |
| Run billing, invoices actions, record payments | ✅ | ✅ | ❌ |
| Invoices view | all | all | own only |
| Finance dashboard | ✅ | ✅ | ❌ |

Customer queries always add `WHERE customer_id = <caller's customer>` in the store layer, never trusting an id from the URL.

---

## 6. API surface (REST, JSON, `/api/v1`)

| Area | Endpoints |
|---|---|
| Auth | `POST /auth/signup` · `/auth/login` · `/auth/logout` · `/auth/forgot` · `/auth/reset` · `GET /auth/me` |
| Users (admin) | `GET/POST /staff` · `PATCH /staff/{id}` (deactivate) |
| Catalog | `CRUD /products` · `/products/{id}/variants` · `/taxes` · `/payment-terms` |
| Plans | `CRUD /plans` (admin write, staff read) |
| Templates | `CRUD /templates` · `POST /templates/{id}/instantiate` → draft subscription |
| Customers | `GET/POST /customers` · `GET/PATCH /customers/{id}` |
| Subscriptions | `GET /subscriptions?status=&customer=&q=&page=` · `POST` · `GET/PATCH {id}` · `POST {id}/transition {to, note}` · `POST {id}/renew` · `GET {id}/events` |
| Discounts | `CRUD /discounts` (admin write) |
| Billing | `POST /billing/run {asOf?, dryRun?}` |
| Invoices | `GET /invoices?status=&overdue=&customer=&from=&to=&page=` · `GET {id}` · `POST {id}/confirm` · `/cancel` · `/send` |
| Payments | `POST /invoices/{id}/payments` · `GET /payments?method=&from=&to=` |
| Reports | `GET /reports/summary?from=&to=` · `/reports/revenue-series?group=month` · `/reports/overdue` |
| Portal | `GET /me/subscriptions` · `POST /me/subscriptions/{id}/transition` · `GET /me/invoices` · `GET /me/invoices/{id}` |

All list endpoints: server-side filter, sort, `limit ≤ 100`, return `{items, total, page}`.

---

## 7. UI plan (Wise look, from `design.md` + screenshots)

**Stack:** Next.js App Router, Tailwind with the `design.md` tokens as CSS variables, `lucide-react` icons (no external icon font), `Inter` via `next/font` (self-hosted, no CDN). Charts: hand-rolled SVG bars/area, no chart lib (`shortcut: swap to recharts if charts multiply`).

**Tokens (copy from design.md, do not invent)**
- Canvas `#FFFFFF`, surface `#F4F5F5`, hairline `#E2E8F0`, dashed `#CBD5E1`
- Brand `#9FE870` on `#163300`; tint `#E8F8DE`; pastel heroes yellow `#FEF08A`, blue `#DBEAFE`, purple `#F3E8FF`
- Radii: pill 9999, hero 24, card 16, inner 12, control 10. Shadows only `diffuse`, `floating`, `drawer`
- Type scale exactly as the table in design.md. Transitions 140–220ms, `cubic-bezier(0.16,1,0.3,1)`

**Shell (matches screenshots):** 240px sticky sidebar, logo `28px 24px 20px`, nav items 44px tall, active = grey pill, sub-menu indent 44px. Top bar 64–72px: breadcrumb left, pills + avatar badge right. Content max-width 1200px, padding `40px 48px 120px`, 40px gap between modules.

**Nav per role**
- Admin/Staff: Home · Subscriptions · Invoices · Payments · Customers · Catalog ▾ (Products, Plans, Templates, Taxes, Discounts) · Insights · Team (admin only)
- Customer: Home · My subscriptions · My invoices · Profile

**Core components** (build once in `frontend/components/ui`)
`Pill` (primary/soft/outline) · `CircleAction` · `BentoHero` · `BentoMetric` · `DashedActionCard` · `GroupedRow` · `StatusBadge` · `DataList` (grouped rows, not bordered tables, with filter pills + pagination) · `Drawer` (560px, portaled to `body`) · `Modal` (24px radius) · `Field` (label, input, inline error) · `PasswordChecklist` · `Skeleton` · `EmptyState` (illustration-free, friendly copy + action) · `Toast`.

**Status colours:** Draft grey, Quotation blue, Confirmed purple, Active green tint, Paused yellow, Closed grey-dark, Paid green, Overdue danger. All pill badges, 12px/600.

**Screens**

| Screen | Content |
|---|---|
| Sign up / Login / Forgot / Reset | centered 440px card on `#F8FAFC`, live password checklist, field-level errors |
| Home (staff) | yellow hero "Run today's billing" (button → `/billing/run`, shows created/skipped), metric bento (active subs, MRR, outstanding, overdue), dashed action cards (New subscription, Record payment, New invoice run), recent invoices grouped rows |
| Subscriptions | filter pills by status, search, grouped rows; row opens Drawer with lines, totals, status timeline, action pills (Confirm, Activate, Pause, Close, Renew) |
| New subscription | stepper modal: customer → template or plan → lines (variant picker, live total) → terms/dates |
| Invoices | filter pills (All, Draft, Confirmed, Paid, Overdue), Drawer with lines, tax, discount, payments, actions (Confirm, Cancel, Send, Print) |
| Payments | list + "Record payment" modal (method, amount defaulted to outstanding, date, note) |
| Catalog pages | list + side drawer forms; product drawer includes variants sub-list |
| Discounts | rule form with kind/value, thresholds, dates, usage meter, product/subscription picker |
| Insights | summary bento (active subs, revenue in range, outstanding, overdue count/amount), revenue-by-month SVG bars, filter pills (range, status), overdue list with "Chase" (mail) action |
| Team (admin) | account owner row + members, Add team member modal (as Wise screenshot) |
| Portal | hero with next invoice due, subscription cards with allowed actions, invoices list + printable view |

**UX rules:** every list has loading skeleton, empty state, error state. Every form shows inline field errors from the API `fields` map. Destructive actions confirm in a modal. Money via `Intl.NumberFormat('en-IN', {style:'currency', currency:'INR'})`. Focus rings and `aria-*` on drawers/modals, keyboard close with Esc.

---

## 8. Repo layout (extends AGENTS.md)

```
backend/internal/
  auth/  users/  catalog/  plans/  templates/  subscriptions/
  billing/   (engine.go, calc.go, calc_test.go, engine_test.go)
  discounts/ taxes/  invoices/  payments/  reports/  mail/  httpx/
backend/migrations/001_init.sql  002_seed_reference.sql
backend/seed/            # 5k subs, 20k invoices, realistic names, 3 demo logins
frontend/app/(auth)/ (staff)/ (portal)/
frontend/components/ui/  frontend/lib/api.ts  frontend/lib/money.ts
docker-compose.yml       # postgres + mailpit
```

Demo accounts (seed): `admin@brightloop.test`, `staff@brightloop.test`, `customer@brightloop.test` (documented in README, strong passwords).

---

## 9. Build order and split

Order is by **risk first**: schema, billing correctness, auth, then screens. UI scaffolding runs in parallel from minute one.

| Block | Thejas (DB + API) | Rohan (UI) |
|---|---|---|
| **B0 — 09:20–10:00** | repo, compose (postgres+mailpit), `001_init.sql`, add `hapt-odoo` | Next.js scaffold, tokens, shell (sidebar, top bar), `Pill`, `Field`, `Drawer`, `Modal` |
| **B1 — 10:00–11:15** | auth + RBAC + reset + staff add, error shape, tests | auth screens with live checklist, role-aware nav, API client |
| **B2 — 11:15–12:45** | catalog (products/variants/taxes/terms), plans, templates | Catalog pages, Plans, Templates (drawer forms) |
| **B3 — 12:45–14:15** | subscriptions + state machine + events; **billing engine + calc + tests** | Subscriptions list/drawer/new stepper |
| **B4 — 14:15–15:15** | discounts + auto-apply, invoices actions, send mail, payments | Invoices, Payments, Discounts screens, print stylesheet |
| **B5 — 15:15–16:00** | reports endpoints, seed 5k/20k, `EXPLAIN` + timing, fix slow queries | Home, Insights, Portal, skeleton/empty/error pass |
| **B6 — 16:00–16:30** | cross-review swap, README + ERD, run AGENTS.md gates | same + demo rehearsal |
| **16:30** | **FREEZE** | |

**Cut list (drop from the bottom if behind, never above the line)**
1. Auth + RBAC, catalog, plans, subscriptions + lifecycle, billing engine, invoices, payments, finance dashboard ← **must ship**
2. Discounts with auto-apply, taxes, templates, portal
3. ———— cut line ————
4. Send-by-email polish, overdue "Chase" mail, revenue chart (use plain metric cards), renew flow, pause

**Commit discipline:** both commit every 30 min on `main`. Swap blocks at B6 so each of you has real commits in the other's area.

---

## 10. Verification (real output, no claims without it)

Backend tests (stdlib `testing`, real Postgres via compose):
1. password rules table test (8 chars fails, 9 with upper/lower/special passes)
2. duplicate email → 409 with field error (case-insensitive)
3. `calc_test`: tax rounding, percent vs fixed, discount clamp, pro-rata sum equals total
4. **billing idempotency:** run engine twice and concurrently, invoice count equals expected
5. discount stops at `usage_limit` and after `end_date`
6. payment overpay rejected; exact payment flips invoice to `paid`
7. RBAC: customer cannot read another customer's invoice (403/404), staff cannot create discount or staff user
8. migration applies on empty DB; seed runs

Perf: after seed, `EXPLAIN (ANALYZE)` on subscriptions list, invoices list, summary report. Every endpoint p95 < 500ms locally; record numbers in README.

---

## 11. Demo script (maps to the statement's scenes)

1. Sign up with a weak password → live checklist; duplicate email error; forgot password → Mailpit link.
2. Admin: create "Odoo-brand" variant (+₹560), a plan, a 10% discount; add a staff member.
3. Staff: template → subscription → Draft → Quotation → Confirmed → Active (timeline).
4. Billing day: **Run billing** → invoices appear with tax + discount; run again → "0 created, N skipped".
5. Confirm, send, print an invoice; record a partial payment, then the rest → Paid.
6. Finance dashboard: active subs, revenue, outstanding, overdue, filters, loads under 2s on 5k subs.
7. Customer portal: sees only their own data, pauses a pausable plan.

Thejas narrates DB + billing, Rohan narrates UI + validation + portal. Both show commit history.
